</div><!-- sixteen columns -->
		
		
		<!-- FOOTER -->
		<div class="sixteen columns">
			<footer>
				<div id="footer_content">
					<div class="sixteen columns alpha">
						<div id="footer_address">
						<p>Mail: info(at)ramundboende.se<br />
						Telefon: 070-3261974 eller 070-6221065<br />
						Adress: Bruksvallarnas Semesterboende AB, Gruvarbetarvägen 14, 840 97 Bruksvallarna</p>
						</div>
					</div>
				
			</div>	
			</footer>
		</div>
		
		
	</div><!-- container -->
</body>
</html>