
	<?php dynamic_sidebar('news_in_sidebar'); ?>
