<?php 
    /*
    Plugin Name: OSCommerce Product Display
    Plugin URI: http://www.orangecreative.net
    Description: Plugin for displaying products from an OSCommerce shopping cart database
    Author: C. Lupu
    Version: 1.0
    Author URI: http://www.orangecreative.net
    */
?>
