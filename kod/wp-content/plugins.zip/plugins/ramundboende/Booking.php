<?php
class Booking {
	//tabeller
	private $m_bookingTableName = "wp_ramundbeonde_booking";
	
	
}
?>